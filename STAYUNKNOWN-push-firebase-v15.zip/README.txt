STAYUNKNOWN Android Firebase push configuration

Replace/add these files in the current STAYUNKNOWN project:
1. app.json -> replace the existing app.json with this version. It adds only:
   expo.android.googleServicesFile = ./google-services.json
   Existing expo-notifications plugin configuration is preserved.
2. google-services.json -> place at the project root.

Do NOT replace package.json or package-lock.json from this patch.

After the files are in the project, a NEW Android Development Build is required because this is native Android configuration.

For iOS push, this Android Firebase file is not used. iOS will be configured separately through EAS/APNs after the Android build is confirmed.
